<?php

class PessoaController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view' ,'function', 'create'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		//Pasta onde as imagens serão salvas.
		$dir = Yii::getPathOfAlias('webroot.images.profiles');
		
		$model=new Pessoa;
		//Configura uma senha padrão
		$model->senha = "Cegov#2012";
		$model->senha_confirm = $model->senha;
		
		//Carrega informações de funções
		if(isset($_POST["Pessoa"]["categorias"]))
		 $model->categorias = $_POST["Pessoa"]["categorias"];
		 
		 //Carreta informações dos GTs
		if(isset($_POST["Pessoa"]["grupos"]))
		 $model->grupos = $_POST["Pessoa"]["grupos"];
		 
		if(isset($_POST['Pessoa']))
		{
			//Carrega os atributos
			$model->attributes=$_POST['Pessoa'];

			//Carrega o arquivo da imagem
			$file = CUploadedFile::getInstance($model,'imageFile');
						
			if($model->save()){
				//O usuário fez um upload de imagem
				if($file != NULL){
					//Salva a url da imagem
					$imgName = $model->cod_pessoa .'.' .$file->getExtensionName();
					$model->imagem = $imgName; 
					$imgDestino = $dir .DIRECTORY_SEPARATOR .$imgName;
					$model->save();
					//Salva arquivo de imagem
					$file->saveAs($imgDestino);
					
				}else{
					//O usuário não fez upload de imagem. Atribui imagem padrão
					$imgName = $model->cod_pessoa .".jpg";
					//Imagem padrão que vai ser copiada para o novo usuário sem imagem.
					$imgSource = $dir .DIRECTORY_SEPARATOR ."membro.jpg";
					//Destino da imagem a ser copiada
					$imgDest = $dir .DIRECTORY_SEPARATOR .$imgName;
					//Copia a imagem
					copy($imgSource, $imgDest);
					//Atribui o link para a nova imagem
					$model->imagem = $imgName;
					$model->save();
				}
				
				
				//Atualiza as funções em categorias da pessoa
				PessoaCategoria::model()->deleteAll('cod_pessoa = '.$model->cod_pessoa);
				
				for($i=0;$i<count($model->categorias);$i++){
							$categoria = new PessoaCategoria();
							$categoria->cod_categoria = $model->categorias[$i];
							$categoria->cod_pessoa = $model->cod_pessoa;
							$categoria->save();
							unset($categoria);
				}
				
				//Atualiza os Grupos de trabalho do qual esta pessoa participa
				PessoaGT::model()->deleteAll('cod_pessoa = '.$model->cod_pessoa);
				
				for($i=0;$i<count($model->grupos);$i++){
							$gt = new PessoaGT();
							$gt->cod_gt = $model->grupos[$i];
							$gt->cod_pessoa = $model->cod_pessoa;
							$gt->save();
							unset($gt);
				}
				
				$this->redirect(array('view','id'=>$model->cod_pessoa));						
			}
				
		}

		$this->render('create',array(
			'model'=>$model,
		));
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate($id)
	{
		//Pasta onde as imagens serão salvas.
		$dir = Yii::getPathOfAlias('webroot.images.profiles');
		
		$model=$this->loadModel($id);

		//Carrega informações de funções
		if(isset($_POST["Pessoa"]["categorias"]))
		 $model->categorias = $_POST["Pessoa"]["categorias"];
		 
		 //Carreta informações dos GTs
		if(isset($_POST["Pessoa"]["grupos"]))
		 $model->grupos = $_POST["Pessoa"]["grupos"];

		if(isset($_POST['Pessoa']))
		{
			$model->attributes=$_POST['Pessoa'];
			
			//Carrega o arquivo da imagem
			$file = CUploadedFile::getInstance($model,'imageFile');
				
			if($model->save()){
				
				if($file != NULL){
					//Salva a url da imagem
					$imgName = $model->cod_pessoa .'.' .$file->getExtensionName();
					$imgDestino = $dir .DIRECTORY_SEPARATOR .$imgName;
					//	deleta a imagem antiga
					unlink($dir .DIRECTORY_SEPARATOR .$model->imagem);
					//Salva arquivo de imagem
					$file->saveAs($imgDestino);
					$model->imagem = $imgName;
					$model->save();
				}
										
				//Salva as categorias que esta pessoa possui.				
				PessoaCategoria::model()->deleteAll('cod_pessoa = '.$model->cod_pessoa);
				for($i=0;$i<count($model->categorias);$i++){
							$categoria = new PessoaCategoria();
							$categoria->cod_categoria = $model->categorias[$i];
							$categoria->cod_pessoa = $model->cod_pessoa;
							$categoria->save();
							unset($categoria);
				}
				
				//Atualiza os Grupos de trabalho do qual esta pessoa participa
				PessoaGT::model()->deleteAll('cod_pessoa = '.$model->cod_pessoa);
				
				for($i=0;$i<count($model->grupos);$i++){
							$gt = new PessoaGT();
							$gt->cod_gt = $model->grupos[$i];
							$gt->cod_pessoa = $model->cod_pessoa;
							$gt->save();
							unset($gt);
				}
				
				
				$this->redirect(array('view','id'=>$model->cod_pessoa));
			}
				
		}

		$this->render('update',array(
			'model'=>$model,
		));
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDelete($id)
	{
		
		// we only allow deletion via POST request
		if(Yii::app()->request->isPostRequest)
		{
			//Carrega a pessoa
			$model = $this->loadModel($id);
			//Monta um array com os GTs que ela atua 
			$gts = array();
			foreach($model->grupos_coordenador as $gt){
				$gts[] = $gt->nome;
			}
			
			//Só deleta se não for coordenador de nenhum GT
			if(count($model->grupos_coordenador)){
				//throw new CHttpException(400, $model->nome . ' não pode ser deletado, pois é coordenador do(s) GT(s): ' .implode(', ', $gts));
				//echo $model->nome . ' não pode ser deletado, pois é coordenador do(s) GT(s): ' .implode(', ', $gts);
				$this->render('error',array('model'=>$model));
			}else{
				
				//Deleta a pessoa
				$model->delete();
			
				// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
				if(!isset($_GET['ajax']))
					$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
				
			}
		}
		else
			throw new CHttpException(400,'Invalid request. Please do not repeat this request again.');
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$data = Categoria::model()->findAll(array('order'=>'t.nome, pessoas.nome', 'with'=>array('pessoas')));
		$this->render('home',array(
			'data'=>$data,
		));
	}
	
	/**
	 * 
	 * Mostra as pessoas de uma determinada categoria
	 * @param integer $id - identificador da categoria
	 */
	
	public function actionFunction($id)
	{
		$dataProvider=new CActiveDataProvider('Pessoa',  array(
			                'criteria' => array(
			                 'with' => array('categorias'),
							'condition'=> 'categorias.cod_categoria = '.$id,
			                'together'=>true)));
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
			'titulo'=>Categoria::model()->findByPk($id)->nome,
		));
	}
	
	
	
/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer the ID of the model to be loaded
	 */
	public function loadModel($id)
	{
		$model=Pessoa::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param CModel the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='pessoa-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
	
	public function actionAdmin()
		{
			$model=new Pessoa('search');
			$model->unsetAttributes();  // clear any default values
			if(isset($_GET['Pessoa']))
				$model->attributes=$_GET['Pessoa'];
	
			$this->render('admin',array(
				'model'=>$model,
			));
	}
}
					