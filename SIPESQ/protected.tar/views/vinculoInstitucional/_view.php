<div class="view">
	<?php echo CHtml::link(CHtml::encode($data->nome), array('view', 'id'=>$data->cod_vinculo_institucional)); ?>
	<br />
</div>