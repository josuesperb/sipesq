<?php $this->pageTitle=Yii::app()->name; ?>

<h1><i>Sistema de Apoio ao Pesquisador</i></h1>
<hr>
<div class="agenda centro">
		<table>
		<thead>
		<tr><th>Segunda</th><th>Terça</th><th>Quarta</th><th>Quinta</th><th>Sexta</th></tr>
		</thead>
		<tbody>
		<tr>
			<td class="manha segunda">Guilherme<br> Gustavo<br> Cepik<br> Aline<br></td>
			<td class="manha terca">Eduardo</td>
			<td class="manha quarta">Eduardo</td>
			<td class="manha quinta">Eduardo</td>
			<td class="manha sexta">Eduardo</td>
		</tr>
		
		<tr class=""><th>Almoço</th></tr>
		<tr>
			<td class="tarde segunda">Guilherme</td>
			<td class="tarde terca">Eduardo</td>
			<td class="tarde quarta">Eduardo</td>
			<td class="tarde quinta">Eduardo</td>
			<td class="tarde sexta">Eduardo</td>
		</tr>
		</tbody>
		
		</table>
	</div>
