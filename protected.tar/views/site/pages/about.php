<?php
$this->pageTitle=Yii::app()->name . ' - Sobre';
$this->breadcrumbs=array(
	'Sobre',
);
?>
<h1>Sobre o SIPESQ</h1>
