	<?php echo CHtml::link(CHtml::encode($data->nome), array('update', 'id'=>$data->cod_categoria)); ?>
	<br />
