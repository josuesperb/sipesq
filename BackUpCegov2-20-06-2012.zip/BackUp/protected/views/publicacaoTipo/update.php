<?php
$this->breadcrumbs=array(
	'Publicacao Tipos'=>array('index'),
	$model->cod_tipo=>array('view','id'=>$model->cod_tipo),
	'Update',
);

$this->menu=array(
	array('label'=>'List PublicacaoTipo', 'url'=>array('index')),
	array('label'=>'Create PublicacaoTipo', 'url'=>array('create')),
	array('label'=>'View PublicacaoTipo', 'url'=>array('view', 'id'=>$model->cod_tipo)),
	array('label'=>'Manage PublicacaoTipo', 'url'=>array('admin')),
);
?>

<h1>Update PublicacaoTipo <?php echo $model->cod_tipo; ?></h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>