<?php
$this->breadcrumbs=array(
	'Publicacao Tipos'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List PublicacaoTipo', 'url'=>array('index')),
	array('label'=>'Manage PublicacaoTipo', 'url'=>array('admin')),
);
?>

<h1>Create PublicacaoTipo</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>