<?php
$this->breadcrumbs=array(
	'Publicacao Tipos',
);

$this->menu=array(
	array('label'=>'Create PublicacaoTipo', 'url'=>array('create')),
	array('label'=>'Manage PublicacaoTipo', 'url'=>array('admin')),
);
?>

<h1>Publicacao Tipos</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
