<?php

//Seta o título para o breadCrumb - ele terá no máximo 60 caracteres
$tituloBrd = substr($model->titulo, 0, 60);
if(count_chars($model->titulo) > 60){
	$tituloBrd .= '...';
} 

$this->breadcrumbs=array(
	'Publicações'=>array('index'),
	$tituloBrd, //Título de no máximo 60 caracteres
);

$this->menu=array(
	array('label'=>'Adicionar', 'url'=>array('create')),
	array('label'=>'Editar', 'url'=>array('update', 'id'=>$model->cod_publicacao)),
	array('label'=>'Deletar', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->cod_publicacao),'confirm'=>'Tem certeza que deseja excluir esta publicação?')),
	array('label'=>'Gerenciar Publicações', 'url'=>array('admin')),
);
?>

	<h3><?php echo CHtml::encode($model->titulo); ?></h3>
	
	<p><?php echo CHtml::encode($model->descricao)?></p>
	
	<b><?php echo CHtml::encode($model->getAttributeLabel('autor')); ?>:</b>
	<?php echo CHtml::encode($model->autor); ?>
	<br />

	<b><?php echo CHtml::encode($model->getAttributeLabel('ano')); ?>:</b>
	<?php echo CHtml::encode($model->ano); ?>
	<br />
	
	<b><?php echo CHtml::encode($model->getAttributeLabel('editora')); ?>:</b>
	<?php echo CHtml::encode($model->editora); ?>
	<br />
	
	<b><?php echo CHtml::encode($model->getAttributeLabel('isbn')); ?>:</b>
	<?php echo CHtml::encode($model->isbn); ?>
	<br />
	
	<b><?php echo CHtml::encode($model->getAttributeLabel('tipo')); ?>:</b>
	<?php echo CHtml::encode($model->tipo->nome); ?>
	<br />
	

	<?php echo CHtml::link(CHtml::encode('Download'),$model->href, array('target'=>'_blank')); ?>
	<br />

