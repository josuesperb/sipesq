<script>
function filtraPublicacao (){

		var pub = $('#pubTipo').val();

		if(pub){
    	 url = '?t=' + pub; 
    	}
    	
    	location.href = url;
	}
</script>
<?php
$this->breadcrumbs=array(
	'Publicações',
);

$this->menu=array(
	array('label'=>'Adicionar Publicação', 'url'=>array('create')),
	array('label'=>'Gerenciar Publicações', 'url'=>array('admin')),
);
?>

<h1>Publicações</h1>

<?php echo CHtml::dropDownList('pubTipo',$publicacao,CHtml::listData(PublicacaoTipo::model()->findAll(array('order'=>'nome')), 'cod_tipo', 'nome'), array('prompt'=>"Selecione um tipo de publicação",'onchange'=>'filtraPublicacao();',));?>

<?php echo CHtml::link("Limpar", 
	array('/publicacao/index'),
	array(
		'class'=>"ui-button ui-button-text-only ui-widget ui-state-default ui-corner-all",
		'id'=>'clean-button',
		'style'=>'padding: 4px;'
		)
	);?>
<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
