<?php
$this->breadcrumbs=array(
	'Publicações'=>array('index'),
	'Adicionar',
);

$this->menu=array(
	array('label'=>'Gerenciar Publicações', 'url'=>array('admin')),
);
?>

<h1>Adicionar Publicação</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>