<?php
$this->breadcrumbs=array(
	'Publicações'=>array('index'),
	'Gerenciar',
);

$this->menu=array(
	array('label'=>'Adicionar Publicação', 'url'=>array('create')),
);

?>

<h1>Gerenciar Publicações</h1>



<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'publicacao-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		'titulo',
		'autor',
		array(
			'class'=>'CButtonColumn',
		),
	),
)); ?>
