<?php

//Seta o título para o breadCrumb - ele terá no máximo 40 caracteres
$tituloBrd = substr($model->titulo, 0, 40);
if(count_chars($model->titulo) > 40){
	$tituloBrd .= '...';
} 

$this->breadcrumbs=array(
	'Publicacaos'=>array('index'),
	$tituloBrd=>array('view','id'=>$model->cod_publicacao),
	'Editar',
);

$this->menu=array(
	array('label'=>'Adicionar Publicação', 'url'=>array('create')),
	array('label'=>'Ver Publicação', 'url'=>array('view', 'id'=>$model->cod_publicacao)),
	array('label'=>'Gerenciar Publicações', 'url'=>array('admin')),
);
?>

<h1> <?php echo $model->titulo; ?></h1>
<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>