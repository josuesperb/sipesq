<div class="form">
<?php 
Yii::app()->clientScript->registerScript('validaArquivo',"

function validaArquivo () {
		if( ($('#Publicacao_file').val() == '') || ($('#Publicacao_href').val() == '')){
			alert('Você deve especificar um arquivo ou um link externo');
			return false;
		}
		return true;
		    

}


");
?>
<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'publicacao-form',
	'enableAjaxValidation'=>false,
	'htmlOptions' => array('enctype'=>'multipart/form-data'),
)); ?>

	<p class="note">Campos com <span class="required">*</span> são obrigatórios.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'titulo'); ?>
		<?php echo $form->textField($model,'titulo', array('size'=>80)); ?>
		<?php echo $form->error($model,'titulo'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'autor'); ?>
		<?php echo $form->textField($model,'autor', array('size'=>80)); ?>
		<?php echo $form->error($model,'autor'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'ano'); ?>
		<?php echo $form->textField($model,'ano', array('size'=>4, 'maxlength'=>4)); ?>
		<?php echo $form->error($model,'ano'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'editora'); ?>
		<?php echo $form->textField($model,'editora'); ?>
		<?php echo $form->error($model,'editora'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'isbn'); ?>
		<?php echo $form->textField($model,'isbn'); ?>
		<?php echo $form->error($model,'isbn'); ?>
	</div>


	<div class="row">
		<?php echo $form->labelEx($model,'cod_tipo'); ?>
		<?php  echo $form->dropDownList($model,'cod_tipo',CHtml::listData(PublicacaoTipo::model()->findAll(array('order'=>'nome')), 'cod_tipo', 'nome'), array('prompt'=>"Selecione um tipo de publicação") ); ?>
		<?php echo $form->error($model,'cod_tipo'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'descricao'); ?>
		<?php echo $form->textArea($model,'descricao',array('rows'=>6, 'cols'=>50)); ?>
		<?php echo $form->error($model,'descricao'); ?>
	</div>
	
	<div class="row">
		<label><b>URL Externa</b></label>
		<?php echo $form->textField($model,'href', array('size'=>80)); ?>
		<?php echo $form->error($model,'href'); ?>
	</div>
	
	<div class="row">
		<?php echo $form->labelEx($model,'file'); ?>
		<?php echo $form->fileField($model,'file'); ?>
		<br><span class="hint">Arquivos com no máximo 20MB</span>
		<br><span class="hint">OBS: No caso da existência de um arquivo a URL externa será ignorada.</span>
		<?php echo $form->error($model,'file'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Adicionar' : 'Salvar', array('id'=>'btnSubmit')); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->