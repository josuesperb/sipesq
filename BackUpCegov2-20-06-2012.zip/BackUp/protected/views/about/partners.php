<?php
$this->breadcrumbs=array(
	"Sobre"=>array('/about/index'),
	$title,
);?>

<?php echo $content?>

<?php if(!Yii::app()->user->isGuest):?>
<div class="row">
<?php echo CHtml::link("Editar", 
	array("/about/updatePartners"),
	array(
		'class'=>"ui-button ui-button-text-only ui-widget ui-state-default ui-corner-all",
		'style'=>'padding: 4px;'
		)
	);?>
</div>
<?php endif;?>

