<li class="ui-state-default" id="<?php echo $data->cod_categoria; ?>">
	<span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
	<?php echo CHtml::encode($data->nome);?>
</li>
