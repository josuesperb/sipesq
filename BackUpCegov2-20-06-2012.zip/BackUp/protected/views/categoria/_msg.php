<div id="msg-window" style="visibility: hidden" title="<?php echo $title?>">
<p id="msg"><?php echo $msg?></p>
</div>