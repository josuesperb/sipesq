<?php 
/**
 * Layout da página de publicações.
 */
?>
<?php $this->beginContent('//layouts/main'); ?>
<div class="container">
	<div class="span-19">
		<div id="content">
			<?php echo $content; ?>
		</div><!-- content -->
	</div>
	<div class="span-5 last">
		<div id="sidebar">
		<?php if(!Yii::app()->user->isGuest):?>
		<?php
			$this->beginWidget('zii.widgets.CPortlet', array(
				'title'=>'Operações',
				'htmlOptions'=>array('visible'=>!Yii::app()->user->isGuest),
			));
			$this->widget('zii.widgets.CMenu', array(
				'items'=>$this->menu,
				
				'htmlOptions'=>array('class'=>'operations'),
			));
			$this->endWidget();
		?>
		<?php endif;?>
		
		<div id="gts">
			<h4>Grupos de Trabalho</h4>
			
			<?php $gts = GrupoTrabalho::model()->findAll(array('order'=>'nome', 'condition'=>'visible = true'))?>
			<ul class="ul-list-item">
			<?php foreach($gts as $gt):?>
				<li class="listItem"><?php echo CHtml::link($gt->nome, array('/gt/view', 'id'=>$gt->cod_gt));?></li>
			<?php endforeach;?>
			</ul>		
		</div>
		<br><hr>
		<div id="pubs">
			<h4>Últimas Publicações</h4>
			<?php $pubs = Publicacao::model()->findAll(array('order'=>'titulo'))?>
			<ul class="ul-list-item">
			<?php foreach($pubs as $pub):?>
			<?php 
			//Seta o título para o breadCrumb - ele terá no máximo 60 caracteres
			$tituloBrd = substr($pub->titulo, 0, 25);
			if(count_chars($pub->titulo) > 25){
				$tituloBrd .= '...';
			} 
			?>
				
				<li class="listItem"><?php echo CHtml::link($tituloBrd, array('/publicacao/view', 'id'=>$pub->cod_publicacao));?></li>
			<?php endforeach;?>
			</ul>		
		</div>
	</div><!-- Sidebar -->
   </div> <!--  Span last5 -->
</div>
<?php $this->endContent(); ?>
