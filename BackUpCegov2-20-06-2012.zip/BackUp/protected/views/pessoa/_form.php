<div class="form">

<?php Yii::app()->clientScript->registerScript('multiple-select',"

	$(\"select[multiple]\").bind(\"mousedown\", function(e) {
    	$(this).data(\"remove\", !$(e.target).is(\":selected\"));
    	$(this).data(\"selected\", $(this).find(\":selected\"));
 	 }).bind(\"mouseup\", function(e){
    	$(this).data(\"selected\").attr(\"selected\", \"selected\");
    	e.target.selected = $(this).data(\"remove\");
  		});
  		
	$(document).ready(
	function(){
	$('#datepicker').datepicker({
					inline: true
				});
	}
	
	);				
");
?>

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'pessoa-form',
	'enableAjaxValidation'=>false,
	'htmlOptions' => array('enctype'=>'multipart/form-data'),
)); ?>

	<p class="note">Campos com <span class="required">*</span> são obrigatórios.</p>

	<?php echo $form->errorSummary($model); ?>
	
	<div class="row">
		<?php echo $form->labelEx($model,'nome'); ?>
		<?php echo $form->textField($model,'nome', array('size'=>70)); ?>
		<?php echo $form->error($model,'nome'); ?>
	</div>
	
	<div class="row">
		<?php echo $form->labelEx($model,'email'); ?>
		<?php echo $form->textField($model,'email', array('size'=>70)); ?>
		<?php echo $form->error($model,'email'); ?>
	</div>
	
	<div class="row">
		<?php echo $form->labelEx($model,'data_nascimento'); ?>
		<?php  $this->widget('zii.widgets.jui.CJuiDatePicker', array(
    			'name'=>'Pessoa[data_nascimento]',
				'value'=>isset($model->data_nascimento) ? $model->data_nascimento : date('d/m/Y'),
				'language'=>'pt-BR',
    			'options'=>array('showAnim'=>'drop','dateFormat'=>'dd/mm/yy'),
			    'htmlOptions'=>array('style'=>'height:15px;'),));
		 ?>
		<?php echo $form->error($model,'data_nascimento'); ?>
		
	</div>
	
	<div id="date_picker" class="hasDatepicker"></div>

	<div class="row">
		<?php echo $form->labelEx($model,'nacionalidade'); ?>
		<?php echo $form->textField($model,'nacionalidade'); ?>
		<?php echo $form->error($model,'nacionalidade'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'telefone'); ?>
		<?php echo $form->textField($model,'telefone'); ?>
		<?php echo $form->error($model,'telefone'); ?>
	</div>
	
	<div class="row">
		<?php echo $form->labelEx($model,'RG'); ?>
		<?php echo $form->textField($model,'RG'); ?>
		<?php echo $form->error($model,'RG'); ?>
	</div>
	
	<div class="row">
		<?php echo $form->labelEx($model,'orgao_expedidor'); ?>
		<?php echo $form->textField($model,'orgao_expedidor'); ?>
		<?php echo $form->error($model,'orgao_expedidor'); ?>
	</div>
	
	<div class="row">
		<?php echo $form->labelEx($model,'CPF'); ?>
		<?php echo $form->textField($model,'CPF'); ?>
		<?php echo $form->error($model,'CPF'); ?>
	</div>
	
	<div class="row">
		<?php echo $form->labelEx($model,'cartao_ufrgs'); ?>
		<?php echo $form->textField($model,'cartao_ufrgs'); ?>
		<?php echo $form->error($model,'cartao_ufrgs'); ?>
	</div>
	
	<div class="row">
		<?php echo $form->labelEx($model,'nome_mae'); ?>
		<?php echo $form->textField($model,'nome_mae', array('size'=>70)); ?>
		<?php echo $form->error($model,'nome_mae'); ?>
	</div>
	
<?php /*	
 <?php if($model->isNewRecord):?>
	<div class="row">
		<?php echo $form->labelEx($model,'senha'); ?>
		<?php echo $form->passwordField($model,'senha'); ?>
		<?php echo $form->error($model,'senha'); ?>
	</div>
	
	<div class="row">
		<?php echo $form->labelEx($model,'senha_confirm'); ?>
		<?php echo $form->passwordField($model,'senha_confirm'); ?>
		<?php echo $form->error($model,'senha_confirm'); ?>
	</div>
<?php endif;?>
*/?>

<br>
	<div class="row">
		<?php echo $form->labelEx($model,'descricao'); ?>
		<?php //echo $form->textArea($model,'descricao',array('rows'=>6, 'cols'=>50)); ?>
		<?php $this->widget('application.extensions.tinymce.ETinyMce', array('htmlOptions'=>array('cols'=>10, 'rows'=>3),'name'=>'Pessoa[descricao]','editorTemplate'=>'simple',  'value'=>$model->descricao, 'height'=>'250px')); ?>
		<?php echo $form->error($model,'descricao'); ?>
	</div>

	<br>
	<div class="row">
		<?php echo $form->labelEx($model,'categorias'); ?>
		<?php  echo $form->listBox($model,'categorias', CHtml::listData(Categoria::model()->findAll(array('order'=>'nome')), 'cod_categoria', 'nome'), array("multiple"=>"multiple", "size"=>Categoria::model()->count())  ); ?>
		<?php echo $form->error($model,'categorias'); ?>
	</div>
	
	<div class="row">
		<?php echo $form->labelEx($model,'grupos'); ?>
		<?php  echo $form->listBox($model,'grupos', CHtml::listData(GrupoTrabalho::model()->findAll(array('order'=>'nome')), 'cod_gt', 'nome'), array("multiple"=>"multiple", "size"=>GrupoTrabalho::model()->count())  ); ?>
		<?php echo $form->error($model,'grupos'); ?>
	</div>
	
	<div class="row">
		<?php echo $form->labelEx($model,'lattes'); ?>
		<?php echo $form->textField($model,'lattes', array('size'=>100)); ?>
		<?php echo $form->error($model,'lattes'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'imageFile'); ?>
		<?php echo $form->fileField($model,'imageFile'); ?>
		<br><span class="hint">Arquivos com aspecto 1:1 e menores que 400kbytes</span>
		<?php echo $form->error($model,'imageFile'); ?>
	</div>
	
	<hr>
	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Adicionar' : 'Salvar'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->