<script>
$("#accordion").accordion({ header: "h3" });
</script>

<?php
$this->breadcrumbs=array(
	'Equipe',
);

$this->menu=array(
	array('label'=>'Adicionar Pessoa', 'url'=>array('create')),
	array('label'=>'Gerenciar Pessoas', 'url'=>array('admin')),
	array('label'=>'Adicionar Categoria', 'url'=>array('categoria/create')),
	array('label'=>'Ordenar Categorias', 'url'=>array('categoria/index')),
	array('label'=>'Gerenciar Categorias', 'url'=>array('categoria/admin')),
);
?>

<h1><?php echo CHtml::encode($titulo)?></h1>
<div id="accordion">
<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
</div>
