<script>

</script>


<?php
Yii::app()->clientScript->registerScriptFile(Yii::app()->request->baseUrl . "/js/jquery-ui.js");
Yii::app()->clientScript->registerScript('accordion',"
	$(document).ready(function(){
		$('#equipe').accordion({ header: 'h4', active: false,  collapsible: true, autoHeight: false });
	});
");
$this->breadcrumbs=array(
	'Equipe',
);

$this->menu=array(
	array('label'=>'Adicionar Pessoa', 'url'=>array('create')),
	array('label'=>'Gerenciar Pessoas', 'url'=>array('admin')),
	array('label'=>'Adicionar Categoria', 'url'=>array('categoria/create')),
	array('label'=>'Ordenar Categorias', 'url'=>array('categoria/index')),
	array('label'=>'Gerenciar Categorias', 'url'=>array('categoria/admin')),
);
?>

<h1>Equipe do CEGOV</h1>

<div id="equipe">
<?php foreach($data as $categoria):?>
	<?php if(count($categoria->pessoas) > 0):?>
		<div>
			<h4><a href="#"><?php echo CHtml::encode($categoria->nome);?></a></h4>
			<div>
			<?php foreach($categoria->pessoas as $p):?> 
				<p style="margin-left: 16px;">
					<?php echo CHtml::image($p->imageLink, 'Imagem pessoal', array('height'=>50, 'width'=>50)); ?>
					<?php echo CHtml::link(CHtml::encode($p->nome),array('/pessoa/view', 'id'=>$p->cod_pessoa));?>
				</p>
			<?php endforeach;?>
			</div>
		</div>
	<?php endif;?>
<?php endforeach;?>
</div>

