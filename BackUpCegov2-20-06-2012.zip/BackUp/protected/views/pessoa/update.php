<?php
$this->breadcrumbs=array(
	'Equipe'=>array('index'),
	$model->nome=>array('view','id'=>$model->cod_pessoa),
	'Editar',
);

$this->menu=array(
	array('label'=>'Listar Pessoas', 'url'=>array('index')),
	array('label'=>'Adicionar Pessoa', 'url'=>array('create')),
);
?>


<div style="float: right;">
	<?php echo CHtml::image($model->imageLink, 'Imagem pessoal', array('height'=>200, 'width'=>200)); ?>
</div>
<h1><?php echo $model->nome; ?></h1>
<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>