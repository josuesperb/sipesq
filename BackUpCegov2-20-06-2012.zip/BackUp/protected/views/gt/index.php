<?php
$this->breadcrumbs=array(
	'Grupos de Trabalho',
);

$this->menu=array(
	array('label'=>'Adicionar Grupo', 'url'=>array('create')),
	array('label'=>'Ordenar Grupos', 'url'=>array('sort')),
	array('label'=>'Gerenciar Grupos', 'url'=>array('admin')),
);


Yii::app()->clientScript->registerScriptFile(Yii::app()->request->baseUrl . "/js/jquery-ui.js");
Yii::app()->clientScript->registerScript('accordion',"
	$(document).ready(function(){
		$('#grupos').accordion({ header: 'h4', active: false,  collapsible: true, autoHeight: false });
		$('#sort').sortable();
		//$( '#sort' ).disableSelection();
		/*
		$('.ui-accordion').bind('accordionchange', function(event, ui) {
 			 //ui.newHeader // jQuery object, activated header
 			 if(ui.newContent.html() != null)
  			 alert(ui.newContent.html()); // jQuery object, previous header
  			 if(ui.newHeader.state == undefined){
  			 	ui.newHeader.state = 'charged';
  			 	alert('carregou');
				}else{
				 alert('ja carregado');	
				}	
 		 	 //ui.newContent // jQuery object, activated content
  			 //ui.oldContent // jQuery object, previous content
		}); */
		
	});
");
?>

<h1>Grupos de Trabalho</h1>

<div id="grupos">
<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
</div>


<?php if(!Yii::app()->user->isGuest): //Mostra para o usuários os GTs inativos?>
<br><br><hr>
<h2>Grupos Inativos</h2>
<?php
	//Busca os GTs inativos
	 $gtsInativos = GrupoTrabalho::model()->findAll(array('condition'=>'visible=false'));
	 //Renderiza todos os GTs inativos
	 foreach($gtsInativos as $gt){
	 	$this->renderPartial('_inativo', array('data'=>$gt));
	 }
?>
<?php endif;?>