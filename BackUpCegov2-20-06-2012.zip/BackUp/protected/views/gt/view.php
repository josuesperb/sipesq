<?php
$this->breadcrumbs=array(
	'Grupos de Trabalho'=>array('index'),
	$model->nome,
);

$this->menu=array(
	array('label'=>'Listar GTs', 'url'=>array('index')),
	array('label'=>'Adicionar GT', 'url'=>array('create')),
	array('label'=>'Gerenciar GTs', 'url'=>array('admin')),
	array('label'=>'Editar', 'url'=>array('update', 'id'=>$model->cod_gt)),
	array('label'=>'Adicionar Projeto', 'url'=>array('createProjeto', 'id'=>$model->cod_gt)),
	array('label'=>'Gerenciar Projetos', 'url'=>array('adminProjeto', 'id'=>$model->cod_gt)),
	array('label'=>'Deletar', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->cod_gt),'confirm'=>'Tem certeza que deseja deletar este GT?')),
	
);
?>

<h1><?php echo CHtml::encode($model->nome); ?></h1>

<div class="view">
	<b><?php echo CHtml::encode($model->getAttributeLabel('cod_coordenador')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($model->coordenador->nome),array('/pessoa/view', 'id'=>$model->cod_coordenador) ); ?>
	<br /><br />
	<?php echo $model->apresentacao; ?>
	<br />
</div>
<?php if(count($model->pessoas) > 0):?>
	<h4>Participantes</h4>
	<div class="view">
	<ul>
		<?php foreach($model->pessoas as $p):?>
			<li><?php echo CHtml::link(CHtml::encode($p->nome), array('/pessoa/view', 'id'=>$p->cod_pessoa));?></li>
		<?php endforeach;?>
	</ul>
	</div>
<?php endif;?>

<?php if(count($model->projetos) > 0):?>
	<h4>Projetos</h4>
	<div class="view">
	<ul>
		<?php foreach($model->projetos as $proj):?>
			<li><?php echo CHtml::link(CHtml::encode($proj->nome), array('/gt/viewProjeto', 'id'=>$proj->cod_projeto));?></li>
		<?php endforeach;?>
	</ul>
	</div>
<?php endif;?>
