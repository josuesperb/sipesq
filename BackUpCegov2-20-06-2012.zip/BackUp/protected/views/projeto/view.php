<?php
$gt = GrupoTrabalho::model()->findByPk($model->cod_gt);

$this->breadcrumbs=array(
	'Grupos de Trabalho'=>array('index'),	
	$gt->nome=>array('view', 'id'=>$gt->cod_gt),
	$model->nome,
);

$this->menu=array(
	array('label'=>'Editar', 'url'=>array('updateProjeto', 'id'=>$model->cod_projeto)),
	array('label'=>'Deletar', 'url'=>'#', 'linkOptions'=>array('submit'=>array('deleteProjeto','id'=>$model->cod_projeto),'confirm'=>'Tem certeza que deseja deletar este projeto?')),
);
?>

<h1><?php echo CHtml::encode($model->nome); ?></h1>
<h4><?php echo CHtml::encode($model->subtitulo); ?></h4>
<div class="view">

	<b><?php echo CHtml::encode($model->getAttributeLabel('texto')); ?>:</b>
	<?php echo CHtml::encode($model->texto); ?>
	<br />

	<b><?php echo CHtml::encode($model->getAttributeLabel('data_inicio')); ?>:</b>
	<?php echo CHtml::encode($model->data_inicio); ?>
	<br />

	<b><?php echo CHtml::encode($model->getAttributeLabel('data_fim')); ?>:</b>
	<?php echo CHtml::encode($model->data_fim); ?>
	<br />

	<b><?php echo CHtml::encode($model->getAttributeLabel('financiador')); ?>:</b>
	<?php echo CHtml::encode($model->financiador); ?>
	<br />

	<b><?php echo CHtml::encode($model->getAttributeLabel('status')); ?>:</b>
	<?php echo CHtml::encode($model->status); ?>
	<br />

	<b><?php echo CHtml::encode($model->getAttributeLabel('tipo_ajuda')); ?>:</b>
	<?php echo CHtml::encode($model->tipo_ajuda); ?>
	<br />

</div>
