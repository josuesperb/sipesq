<?php

/**
 * This is the model class for table "publicacao".
 *
 * The followings are the available columns in table 'publicacao':
 * @property integer $cod_publicacao
 * @property string $titulo
 * @property string $autor
 * @property string $ano
 * @property string $editora
 * @property string $isbn
 * @property integer $cod_tipo
 * @property string $descricao
 * @property string $href
 * @property string $file - handler para arquivos
 *
 * The followings are the available model relations:
 * @property PublicacaoTipo $tipo
 */
class Publicacao extends CActiveRecord
{
	
	public  $file;
	
	/**
	 * Returns the static model of the specified AR class.
	 * @return Publicacao the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'publicacao';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('titulo, autor, ano, editora, isbn, descricao, cod_tipo', 'required'),
			array('cod_tipo', 'numerical', 'integerOnly'=>true),
			array('href', 'safe'),
			array('file', 'validaArquivos'),
			array('file', 'file',
				 'types'=>'pdf, doc, docx, rtf, odt', 
				 'allowEmpty'=>true,
				 //'tooLarge'	=>"Este arquivo é muito grande. Ele deve ter no máximo 20MB",
				 //'maxSize'=> 1024*1024*20 //20MB
					),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('cod_publicacao, href, titulo, autor, ano, editora, isbn, file, cod_tipo, descricao', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'tipo' => array(self::BELONGS_TO, 'PublicacaoTipo', 'cod_publicacao'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'cod_publicacao' => 'ID',
			'titulo' => 'Título',
			'autor' => 'Autor',
			'ano' => 'Ano',
			'editora' => 'Editora',
			'isbn' => 'ISBN',
			'file' => 'Arquivo',
			'cod_tipo' => 'Tipo de Publicação',
			'descricao' => 'Descrição',
			'href'=> 'URL',
			'tipo'=>'Tipo de Publicação',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('cod_publicacao',$this->cod_publicacao);
		$criteria->compare('titulo',$this->titulo,true);
		$criteria->compare('autor',$this->autor,true);
		$criteria->compare('ano',$this->ano,true);
		$criteria->compare('editora',$this->editora,true);
		$criteria->compare('isbn',$this->isbn,true);
		$criteria->compare('file',$this->file,true);
		$criteria->compare('cod_tipo',$this->cod_tipo);
		$criteria->compare('descricao',$this->descricao,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}
	
	public function validaArquivos($attribute, $params){
			
			$file = CUploadedFile::getInstance($this,'file');
		
			if(($this->href == NULL) &&  ($file == NULL) ){
			 	$this->addError($attribute, 'Você deve especificar um link externo ou fazer upload de um arquivo.');
			}
	}
}